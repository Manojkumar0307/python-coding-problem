# Easy Coding Test Solutions

## Language Used
Python 3

## Files Included

- `Program-1.py`: Simple calculator using class and if-else logic.
- `Program-2.py`: Generate first x odd numbers starting from 1.
- `Program-3.py`: Generate odd numbers up to closest odd <= x.
- `Program-4.py`: Count how many numbers in a list are divisible by 1 through 9.

## How to Run

Each file is standalone. Run using Python 3:

```bash
python Program-1.py
```
Replace with the desired file name.
