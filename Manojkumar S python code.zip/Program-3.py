def generate_limited_series(a):
    series = []
    limit = a if a % 2 != 0 else a - 1
    for i in range(1, limit + 1, 2):
        series.append(i)
    return series

# Example usage
a = int(input("Enter a number: "))
print(generate_limited_series(a))
