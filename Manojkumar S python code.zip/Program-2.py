def generate_series(a):
    series = []
    for i in range(a):
        series.append(2 * i + 1)
    return series

# Example usage
a = int(input("Enter a number: "))
print(generate_series(a))
